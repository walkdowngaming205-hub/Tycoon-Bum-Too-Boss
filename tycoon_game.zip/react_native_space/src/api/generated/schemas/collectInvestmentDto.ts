// @ts-nocheck

export interface CollectInvestmentDto {
  investmentId: number;
}
