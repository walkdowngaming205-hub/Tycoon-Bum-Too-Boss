// @ts-nocheck

export type BuyVehicleDtoVehicleKey = typeof BuyVehicleDtoVehicleKey[keyof typeof BuyVehicleDtoVehicleKey];


export const BuyVehicleDtoVehicleKey = {
  sedan: 'sedan',
  van: 'van',
  supercar: 'supercar',
} as const;
