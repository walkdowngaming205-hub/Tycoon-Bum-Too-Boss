// @ts-nocheck

export type SpendBossCoinsDtoItemKey = typeof SpendBossCoinsDtoItemKey[keyof typeof SpendBossCoinsDtoItemKey];


export const SpendBossCoinsDtoItemKey = {
  energy_refill: 'energy_refill',
  business_rename: 'business_rename',
  offline_boost: 'offline_boost',
  xp_booster: 'xp_booster',
  avatar_frame: 'avatar_frame',
} as const;
