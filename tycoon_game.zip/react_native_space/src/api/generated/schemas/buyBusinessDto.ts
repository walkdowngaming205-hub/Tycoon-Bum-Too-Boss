// @ts-nocheck
import type { BuyBusinessDtoBusinessType } from './buyBusinessDtoBusinessType';

export interface BuyBusinessDto {
  businessType: BuyBusinessDtoBusinessType;
}
