// @ts-nocheck

export type BuyBusinessDtoBusinessType = typeof BuyBusinessDtoBusinessType[keyof typeof BuyBusinessDtoBusinessType];


export const BuyBusinessDtoBusinessType = {
  lemonade_stand: 'lemonade_stand',
  car_wash: 'car_wash',
  food_truck: 'food_truck',
  barbershop: 'barbershop',
  restaurant: 'restaurant',
  nightclub: 'nightclub',
  hotel: 'hotel',
  tech_hq: 'tech_hq',
} as const;
