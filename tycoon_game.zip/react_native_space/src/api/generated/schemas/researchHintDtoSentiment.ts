// @ts-nocheck

export type ResearchHintDtoSentiment = typeof ResearchHintDtoSentiment[keyof typeof ResearchHintDtoSentiment];


export const ResearchHintDtoSentiment = {
  bearish: 'bearish',
  neutral: 'neutral',
  bullish: 'bullish',
} as const;
