// @ts-nocheck

export interface ResolveEventDto {
  /**
     * @minimum 0
     * @maximum 3
     */
  choiceIndex: number;
  adProtection?: boolean;
}
