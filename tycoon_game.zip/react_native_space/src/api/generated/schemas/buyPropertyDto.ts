// @ts-nocheck
import type { BuyPropertyDtoPropertyKey } from './buyPropertyDtoPropertyKey';

export interface BuyPropertyDto {
  propertyKey: BuyPropertyDtoPropertyKey;
}
