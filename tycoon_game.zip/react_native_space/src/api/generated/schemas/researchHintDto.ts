// @ts-nocheck
import type { ResearchHintDtoSentiment } from './researchHintDtoSentiment';

export interface ResearchHintDto {
  opportunityKey: string;
  sentiment: ResearchHintDtoSentiment;
}
