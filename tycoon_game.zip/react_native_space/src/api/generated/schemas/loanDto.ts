// @ts-nocheck

export interface LoanDto {
  /** @minimum 1 */
  amount: number;
}
