// @ts-nocheck

export type InvestDtoOpportunityKey = typeof InvestDtoOpportunityKey[keyof typeof InvestDtoOpportunityKey];


export const InvestDtoOpportunityKey = {
  blue_chip: 'blue_chip',
  real_estate_fund: 'real_estate_fund',
  gold_bullion: 'gold_bullion',
  penny_stock: 'penny_stock',
  startup_angel: 'startup_angel',
  crypto_coin: 'crypto_coin',
} as const;
