// @ts-nocheck

export interface PendingEventDto {
  key: string;
  title: string;
  description: string;
  choices: string[];
}
