// @ts-nocheck

export type ResearchDtoOpportunityKey = typeof ResearchDtoOpportunityKey[keyof typeof ResearchDtoOpportunityKey];


export const ResearchDtoOpportunityKey = {
  blue_chip: 'blue_chip',
  real_estate_fund: 'real_estate_fund',
  gold_bullion: 'gold_bullion',
  penny_stock: 'penny_stock',
  startup_angel: 'startup_angel',
  crypto_coin: 'crypto_coin',
} as const;
