// @ts-nocheck

export type HustleDtoHustleType = typeof HustleDtoHustleType[keyof typeof HustleDtoHustleType];


export const HustleDtoHustleType = {
  wash_cars: 'wash_cars',
  lawn_care: 'lawn_care',
  deliver_food: 'deliver_food',
  cleaning: 'cleaning',
  moving: 'moving',
  sneaker_resell: 'sneaker_resell',
  phone_repair: 'phone_repair',
  food_stand: 'food_stand',
  clothing_resell: 'clothing_resell',
} as const;
