// @ts-nocheck

export interface OfflineIncomeDto {
  amount: number;
  secondsAway: number;
  cappedAtHours: number;
}
