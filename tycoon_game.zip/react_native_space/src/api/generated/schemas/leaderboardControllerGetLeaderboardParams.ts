// @ts-nocheck

export type LeaderboardControllerGetLeaderboardParams = {
limit?: number;
};
