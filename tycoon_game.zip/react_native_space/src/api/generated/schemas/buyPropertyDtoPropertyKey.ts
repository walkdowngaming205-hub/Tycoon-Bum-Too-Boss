// @ts-nocheck

export type BuyPropertyDtoPropertyKey = typeof BuyPropertyDtoPropertyKey[keyof typeof BuyPropertyDtoPropertyKey];


export const BuyPropertyDtoPropertyKey = {
  duplex: 'duplex',
  apartment_block: 'apartment_block',
  loft_tower: 'loft_tower',
  skyscraper: 'skyscraper',
} as const;
