// @ts-nocheck

export type AdRewardDtoRewardType = typeof AdRewardDtoRewardType[keyof typeof AdRewardDtoRewardType];


export const AdRewardDtoRewardType = {
  offline_double: 'offline_double',
  business_boost: 'business_boost',
  energy_refill: 'energy_refill',
  free_research: 'free_research',
  daily_double: 'daily_double',
} as const;
