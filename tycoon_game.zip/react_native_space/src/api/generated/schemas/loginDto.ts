// @ts-nocheck

export interface LoginDto {
  email: string;
  password: string;
}
