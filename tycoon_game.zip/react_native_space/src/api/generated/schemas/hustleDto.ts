// @ts-nocheck
import type { HustleDtoHustleType } from './hustleDtoHustleType';

export interface HustleDto {
  hustleType: HustleDtoHustleType;
}
