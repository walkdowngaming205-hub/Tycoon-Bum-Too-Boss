// @ts-nocheck
import type { BuyVehicleDtoVehicleKey } from './buyVehicleDtoVehicleKey';

export interface BuyVehicleDto {
  vehicleKey: BuyVehicleDtoVehicleKey;
}
