// @ts-nocheck

export interface BusinessIdDto {
  businessId: number;
}
