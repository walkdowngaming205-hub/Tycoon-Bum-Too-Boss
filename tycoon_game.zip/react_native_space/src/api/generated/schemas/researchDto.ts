// @ts-nocheck
import type { ResearchDtoOpportunityKey } from './researchDtoOpportunityKey';

export interface ResearchDto {
  opportunityKey: ResearchDtoOpportunityKey;
}
