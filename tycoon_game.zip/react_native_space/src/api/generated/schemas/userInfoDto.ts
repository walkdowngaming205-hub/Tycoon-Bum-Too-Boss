// @ts-nocheck

export interface UserInfoDto {
  id: number;
  email: string;
  name: string;
  playerName: string;
  avatarEmoji: string;
  createdAt?: string;
}
