export const COLORS = {
  bg: '#0E0E1A',
  bgDeep: '#07070F',
  card: 'rgba(255,255,255,0.05)',
  cardSolid: '#16182A',
  cardElevated: '#1E2035',
  cardBorder: 'rgba(255,255,255,0.09)',
  gold: '#F5C542',
  goldDark: '#D99A1E',
  green: '#22C55E',
  emerald: '#10B981',
  violet: '#7C3AED',
  red: '#EF4444',
  cyan: '#06B6D4',
  orange: '#F97316',
  white: '#F4F4F8',
  textSecondary: '#A3AAC4',
  textMuted: '#6B7290',
  overlay: 'rgba(5,5,12,0.85)',
};

export const GRADIENTS = {
  bg: ['#141428', '#0B0B16', '#07070F'] as const,
  gold: ['#FCD34D', '#F59E0B'] as const,
  green: ['#34D399', '#059669'] as const,
  violet: ['#8B5CF6', '#6D28D9'] as const,
  red: ['#F87171', '#DC2626'] as const,
  cyan: ['#22D3EE', '#0891B2'] as const,
  disabled: ['#3A3D52', '#2A2C3D'] as const,
  imageFade: ['transparent', 'rgba(7,7,15,0.55)', 'rgba(7,7,15,0.96)'] as const,
};

export const SPACING = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32, xxl: 48 };
export const RADIUS = { sm: 8, md: 12, lg: 16, xl: 24, full: 9999 };
