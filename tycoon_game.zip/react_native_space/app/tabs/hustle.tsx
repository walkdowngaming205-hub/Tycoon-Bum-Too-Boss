import React, { useCallback } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useGame } from '@/src/contexts/GameContext';
import { gameControllerHustle, gameControllerSpendBossCoins } from '@/src/api/generated/api';
import type { HustleDtoHustleType } from '@/src/api/generated/schemas';
import { Badge, Card, GradientButton, LoadingState, ProgressBar, ScreenBackground, ScreenTitle, StatPill } from '@/src/components/ui';
import { HUSTLES, formatCash, type HustleDef } from '@/src/constants/game';
import { COLORS, GRADIENTS, RADIUS, SPACING } from '@/src/constants/theme';

type IconName = React.ComponentProps<typeof Ionicons>['name'];

export default function HustleScreen() {
  const { gs, loading, loadError, refresh, act, busyKey, displayEnergy, displayCash, watchAd } = useGame();

  const doHustle = useCallback((h: HustleDef) => {
    act(`hustle-${h.key}`, () => gameControllerHustle({ hustleType: h.key as HustleDtoHustleType }));
  }, [act]);

  if (!gs) return <ScreenBackground><LoadingState error={loading ? null : loadError} onRetry={refresh} /></ScreenBackground>;

  const mult = (1 + (gs.reputation ?? 0) / 100) * (1 + (gs.hustleBonus ?? 0));
  const maxE = gs.maxEnergy ?? 100;
  const full = displayEnergy >= maxE;

  const header = (
    <>
      <ScreenTitle title="Hustle" subtitle="Grind for cash & XP. Energy refills over time." right={<StatPill icon="cash" value={formatCash(displayCash)} />} />
      <Card style={{ marginBottom: SPACING.md }}>
        <View style={s.rowBetween}>
          <View style={s.row}><Ionicons name="flash" size={18} color={COLORS.cyan} /><Text style={s.energyText}>{displayEnergy} / {maxE}</Text></View>
          <Text style={s.hint}>+1 every {gs.energyRegenSeconds ?? 20}s</Text>
        </View>
        <ProgressBar progress={displayEnergy / Math.max(1, maxE)} colors={GRADIENTS.cyan} height={12} style={{ marginVertical: 12 }} />
        <View style={s.bonusRow}>
          <Badge text={`Rep +${gs.reputation ?? 0}%`} color={COLORS.violet} icon="shield-checkmark" />
          <Badge text={`Vehicle +${Math.round((gs.hustleBonus ?? 0) * 100)}%`} color={COLORS.cyan} icon="car-sport" />
          <Badge text={`Total ×${mult.toFixed(2)}`} color={COLORS.gold} icon="trending-up" />
        </View>
        {!full ? (
          <View style={[s.row, { gap: 8, marginTop: 12 }]}>
            <GradientButton small title="Refill (Ad)" icon="play-circle" variant="violet" onPress={() => watchAd('energy_refill')} style={{ flex: 1 }} />
            <GradientButton small title="Refill · 10 💎" variant="cyan" disabled={(gs.bossCoins ?? 0) < 10} loading={busyKey === 'refill'}
              onPress={() => act('refill', () => gameControllerSpendBossCoins({ itemKey: 'energy_refill' }))} style={{ flex: 1 }} />
          </View>
        ) : null}
      </Card>
    </>
  );

  return (
    <ScreenBackground>
      <FlatList
        data={HUSTLES}
        keyExtractor={(h) => h.key}
        ListHeaderComponent={header}
        contentContainerStyle={s.content}
        renderItem={({ item }) => (
          <HustleRow
            h={item}
            payout={item.reward * mult}
            locked={(gs.level ?? 1) < item.unlockLevel}
            noEnergy={displayEnergy < item.energy}
            busy={busyKey === `hustle-${item.key}`}
            onPress={doHustle}
          />
        )}
      />
    </ScreenBackground>
  );
}

const HustleRow = React.memo(function HustleRow({ h, payout, locked, noEnergy, busy, onPress }: { h: HustleDef; payout: number; locked: boolean; noEnergy: boolean; busy: boolean; onPress: (h: HustleDef) => void }) {
  const risky = h.successRate !== undefined;
  return (
    <Pressable
      disabled={locked || busy}
      onPress={() => onPress(h)}
      style={({ pressed }) => [s.item, locked && { opacity: 0.45 }, pressed && { transform: [{ scale: 0.98 }] }]}
      accessibilityRole="button"
      accessibilityLabel={`${h.name}${locked ? `, locked until level ${h.unlockLevel}` : ''}`}
    >
      <LinearGradient colors={locked ? GRADIENTS.disabled : risky ? GRADIENTS.red : GRADIENTS.gold} style={s.icon}>
        <Ionicons name={(locked ? 'lock-closed' : h.icon) as IconName} size={22} color={locked ? COLORS.textMuted : risky ? '#fff' : '#1A1305'} />
      </LinearGradient>
      <View style={{ flex: 1 }}>
        <View style={s.row}>
          <Text style={s.name}>{h.name}</Text>
          {risky && !locked ? <Badge text={`${Math.round((h.successRate ?? 1) * 100)}% win`} color={COLORS.orange} /> : null}
        </View>
        <Text style={s.meta}>
          {locked ? `Unlocks at level ${h.unlockLevel}` : `⚡ ${h.energy}  ·  +${h.xp} XP${risky ? `  ·  risk -${formatCash(h.failLoss)}` : ''}`}
        </Text>
      </View>
      <View style={s.payoutBox}>
        <Text style={[s.payout, noEnergy && !locked && { color: COLORS.textMuted }]}>{formatCash(payout)}</Text>
        {!locked ? <Text style={s.tap}>{busy ? '…' : noEnergy ? 'No energy' : 'TAP'}</Text> : null}
      </View>
    </Pressable>
  );
});

const s = StyleSheet.create({
  content: { padding: SPACING.md, paddingBottom: SPACING.xxl },
  row: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  rowBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  energyText: { color: COLORS.white, fontSize: 18, fontWeight: '900' },
  hint: { color: COLORS.textMuted, fontSize: 12, fontWeight: '600' },
  bonusRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  item: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.card, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.cardBorder, padding: 12, marginBottom: 10, minHeight: 72 },
  icon: { width: 48, height: 48, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  name: { color: COLORS.white, fontSize: 16, fontWeight: '800' },
  meta: { color: COLORS.textSecondary, fontSize: 12, marginTop: 4 },
  payoutBox: { alignItems: 'flex-end', marginLeft: 8 },
  payout: { color: COLORS.green, fontSize: 16, fontWeight: '900' },
  tap: { color: COLORS.gold, fontSize: 11, fontWeight: '900', marginTop: 2, letterSpacing: 1 },
});
