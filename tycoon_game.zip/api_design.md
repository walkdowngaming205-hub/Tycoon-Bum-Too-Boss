# Bum to Boss Tycoon — API Specification

Base URL: `/api`
All authenticated endpoints require `Authorization: Bearer <token>` header.
All responses use JSON. Errors: `{error: string, statusCode: integer}`.

---

## Auth Endpoints

| Method | Path | Request Body | Response Body | Auth |
|--------|------|-------------|---------------|------|
| POST | /api/signup | {email: string (required), password: string (required), name: string (required), playerName: string (required), avatarEmoji: string (optional, default "😎")} | {token: string, user: {id: UUID, email: string, name: string, playerName: string, avatarEmoji: string}} | No |
| POST | /api/auth/login | {email: string (required), password: string (required)} | {token: string, user: {id: UUID, email: string, name: string, playerName: string, avatarEmoji: string}} | No |
| GET | /api/auth/me | — | {user: {id: UUID, email: string, name: string, playerName: string, avatarEmoji: string, createdAt: ISO8601}} | Bearer |

Notes:
- Signup creates User + initial GameState (cash: 50, bossCoins: 50, level: 1, xp: 0) + empty achievements for all 9 achievement keys.
- `name` and `playerName` both set to the provided `playerName` value (name is required by predetermined contract).
- Password: bcrypt hashed, min 6 characters.
- JWT: 7-day expiry.

---

## Game State Endpoints

### GET /api/game/state — Load Game State (with offline income)

| Method | Path | Request Body | Response Body | Auth |
|--------|------|-------------|---------------|------|
| GET | /api/game/state | — | See below | Bearer |

**Response:**
```
{
  gameState: {
    id: UUID,
    cash: number,
    xp: integer,
    level: integer,
    bossCoins: integer,
    totalEarned: number,
    totalHustleTaps: integer,
    reputation: integer,
    investmentReturns: number,
    investmentWinRate: number,
    weekStartNetWorth: number,
    weekStartDate: ISO8601,
    offlineMaxHours: integer,
    xpBoostUntil: ISO8601 | null,
    lastActiveAt: ISO8601,
    adCountToday: integer,
    adCountResetDate: ISO8601
  },
  businesses: [
    {
      id: UUID,
      businessType: string,
      level: integer,
      customName: string | null,
      incomeBoostUntil: ISO8601 | null,
      purchasedAt: ISO8601,
      incomePerSecond: number  // computed: base rate × level multiplier × boost
    }
  ],
  achievements: [
    {
      id: UUID,
      achievementKey: string,
      progress: integer,
      completed: boolean,
      completedAt: ISO8601 | null
    }
  ],
  offlineIncome: {
    amount: number,
    secondsAway: integer,
    cappedAtHours: integer
  } | null,
  playerName: string,
  avatarEmoji: string,
  hasAvatarFrame: boolean
}
```

**Backend logic:**
- Calculate seconds since `lastActiveAt`, cap at `offlineMaxHours * 3600`
- Sum passive income from all businesses (considering boost expiry)
- `offlineIncome.amount` = totalPassivePerSecond × cappedSeconds
- Do NOT add offline income to cash yet — client confirms collection
- Reset `adCountToday` to 0 if `adCountResetDate` < today
- Update `lastActiveAt` to now
- `hasAvatarFrame`: derived from whether user has purchased the Premium Avatar Frame (check via a flag or boss coin purchase history)

### PUT /api/game/state — Sync Game State

| Method | Path | Request Body | Response Body | Auth |
|--------|------|-------------|---------------|------|
| PUT | /api/game/state | {cash: number (required), xp: integer (required), level: integer (required), bossCoins: integer (required), totalEarned: number (required), totalHustleTaps: integer (required), reputation: integer (optional), adCountToday: integer (optional)} | {success: boolean, lastActiveAt: ISO8601} | Bearer |

**Backend logic:**
- Update GameState fields for the authenticated user
- Set `lastActiveAt` to now
- Validate: cash >= 0, level >= 1, bossCoins >= 0

---

## Hustle Endpoints

### POST /api/game/hustle — Perform a Hustle

| Method | Path | Request Body | Response Body | Auth |
|--------|------|-------------|---------------|------|
| POST | /api/game/hustle | {hustleType: string (required, one of: "wash_cars", "deliver_food", "sell_lemonade")} | {cash: number, xp: integer, level: integer, bossCoins: integer, totalHustleTaps: integer, totalEarned: number, leveledUp: boolean, newLevel: integer | null, bossCoinsAwarded: integer, achievementsUnlocked: string[]} | Bearer |

**Backend logic:**
- Validate player level meets hustle requirement (wash_cars: 1, deliver_food: 2, sell_lemonade: 3)
- Add cash reward: wash_cars=$5, deliver_food=$12, sell_lemonade=$20
- Add XP: wash_cars=2, deliver_food=5, sell_lemonade=8
- If xpBoostUntil > now, double XP
- Check level-up: XP threshold = 100 × 1.5^(level-1). If XP >= threshold: level++, XP -= threshold, leveledUp=true
- If new level is multiple of 5: award 20 bossCoins
- Increment totalHustleTaps, totalEarned
- Check achievements: update progress for "hustler" (totalHustleTaps), "first_1000" (totalEarned), "level_5" (level), "boss_coins_earner" (total bossCoins earned). Mark completed if threshold met, award boss coins.
- Return updated state + any achievements unlocked

---

## Business Endpoints

### POST /api/game/business/buy — Buy a Business

| Method | Path | Request Body | Response Body | Auth |
|--------|------|-------------|---------------|------|
| POST | /api/game/business/buy | {businessType: string (required, one of: "lemonade_stand")} | {cash: number, business: {id: UUID, businessType: string, level: integer, customName: string | null, incomeBoostUntil: ISO8601 | null, purchasedAt: ISO8601, incomePerSecond: number}, achievementsUnlocked: string[]} | Bearer |

**Backend logic:**
- Validate business not already owned
- Validate sufficient cash (lemonade_stand: $50)
- Deduct cash, create Business record (level 1)
- Income rates: lemonade_stand base = $0.5/sec
- Check achievements: "first_business"
- Return updated cash + new business

### POST /api/game/business/upgrade — Upgrade a Business

| Method | Path | Request Body | Response Body | Auth |
|--------|------|-------------|---------------|------|
| POST | /api/game/business/upgrade | {businessId: UUID (required)} | {cash: number, business: {id: UUID, businessType: string, level: integer, customName: string | null, incomeBoostUntil: ISO8601 | null, purchasedAt: ISO8601, incomePerSecond: number}, achievementsUnlocked: string[]} | Bearer |

**Backend logic:**
- Validate business exists and belongs to user
- Validate level < 3 (max level)
- Upgrade costs: L1→L2 = $150, L2→L3 = $450 (3x previous)
- Validate sufficient cash
- Deduct cash, increment level
- Income doubles per level: L1=$0.5/s, L2=$1.0/s, L3=$2.0/s
- Check achievements: "upgraded" (business at L2+)
- Return updated cash + business

---

## Boss Coins Endpoints

### POST /api/game/boss-coins/spend — Spend Boss Coins

| Method | Path | Request Body | Response Body | Auth |
|--------|------|-------------|---------------|------|
| POST | /api/game/boss-coins/spend | {itemKey: string (required), targetBusinessId: UUID (optional)} | {bossCoins: integer, cash: number, xpBoostUntil: ISO8601 | null, offlineMaxHours: integer, hasAvatarFrame: boolean, achievementsUnlocked: string[]} | Bearer |

**Item keys and effects:**
- `skip_cooldown` (5 💎): No server-side effect, client resets cooldown timer
- `business_rename` (10 💎): requires `targetBusinessId` + `newName: string` in request body
- `offline_boost` (25 💎): sets offlineMaxHours = 6
- `xp_booster` (20 💎): sets xpBoostUntil = now + 1 hour
- `cash_500` (30 💎): adds $500 to cash
- `cash_2000` (100 💎): adds $2000 to cash
- `avatar_frame` (50 💎): sets hasAvatarFrame flag (store in GameState or separate field)

**Backend logic:**
- Validate sufficient bossCoins
- Deduct bossCoins
- Apply effect
- Return updated relevant fields

---

## Ad Tracking Endpoint

### POST /api/game/ad-reward — Record Ad Watch and Apply Reward

| Method | Path | Request Body | Response Body | Auth |
|--------|------|-------------|---------------|------|
| POST | /api/game/ad-reward | {rewardType: string (required, one of: "offline_double", "business_boost"), offlineAmount: number (optional, required for offline_double), targetBusinessId: UUID (optional, required for business_boost)} | {cash: number, adCountToday: integer, business: {id: UUID, businessType: string, level: integer, incomeBoostUntil: ISO8601, incomePerSecond: number} | null} | Bearer |

**Backend logic:**
- Check adCountToday < 5 (reset if adCountResetDate < today)
- Increment adCountToday, set adCountResetDate to today if reset
- `offline_double`: add offlineAmount to cash (the original amount was already added by client on collect)
- `business_boost`: set incomeBoostUntil = now + 30 minutes on target business
- Return updated state

---

## Offline Income Collection

### POST /api/game/collect-offline — Collect Offline Income

| Method | Path | Request Body | Response Body | Auth |
|--------|------|-------------|---------------|------|
| POST | /api/game/collect-offline | {amount: number (required)} | {cash: number, totalEarned: number, achievementsUnlocked: string[]} | Bearer |

**Backend logic:**
- Validate amount matches server-calculated offline income (within small tolerance)
- Add to cash and totalEarned
- Check achievements: "first_1000", "millionaire"
- Return updated values

---

## Leaderboard Endpoints

### GET /api/leaderboard/:type — Get Leaderboard

| Method | Path | Request Body | Response Body | Auth |
|--------|------|-------------|---------------|------|
| GET | /api/leaderboard/:type | query: ?limit=integer (default 50) | {entries: LeaderboardEntry[], myRank: LeaderboardEntry | null} | Bearer |

**Type values:** `networth`, `empire`, `investment`, `reputation`, `weekly`

**LeaderboardEntry shape per type:**

**networth:**
```
{rank: integer, userId: UUID, playerName: string, avatarEmoji: string, netWorth: number, level: integer}
```
Sort: cash + sum(business values) DESC. Business value = purchase cost × level.

**empire:**
```
{rank: integer, userId: UUID, playerName: string, avatarEmoji: string, empireValue: number, businessCount: integer}
```
Sort: sum(business values) DESC.

**investment:**
```
{rank: integer, userId: UUID, playerName: string, avatarEmoji: string, investmentReturns: number, winRate: number}
```
Sort: investmentReturns DESC.

**reputation:**
```
{rank: integer, userId: UUID, playerName: string, avatarEmoji: string, reputation: integer, title: string}
```
Sort: reputation DESC. Title derived: 0-20="Rookie", 21-40="Hustler", 41-60="Entrepreneur", 61-80="Mogul", 81-100="Tycoon".

**weekly:**
```
{rank: integer, userId: UUID, playerName: string, avatarEmoji: string, weeklyGrowth: number}
```
Sort: (current net worth - weekStartNetWorth) DESC. Only include users whose weekStartDate is current week's Monday.

**Backend logic:**
- Query all users (including seeded dummy users), compute ranking
- `myRank`: find authenticated user's position in full ranking
- Weekly: on first request after Monday 00:00 UTC, snapshot current net worth into weekStartNetWorth and set weekStartDate

---

## Business Definitions (Server Constants)

```
BUSINESS_DEFS = {
  lemonade_stand: {
    name: "Lemonade Stand",
    emoji: "🍋",
    cost: 50,
    baseIncomePerSecond: 0.5,
    upgradeCosts: [150, 450],  // L1→L2, L2→L3
    incomeMultipliers: [1, 2, 4]  // L1, L2, L3
  }
}
```

## Hustle Definitions (Server Constants)

```
HUSTLE_DEFS = {
  wash_cars: { name: "Wash Cars", emoji: "🚗", reward: 5, xp: 2, cooldown: 3, unlockLevel: 1 },
  deliver_food: { name: "Deliver Food", emoji: "🍔", reward: 12, xp: 5, cooldown: 6, unlockLevel: 2 },
  sell_lemonade: { name: "Sell Lemonade", emoji: "🍋", reward: 20, xp: 8, cooldown: 10, unlockLevel: 3 }
}
```

## Achievement Definitions (Server Constants)

```
ACHIEVEMENT_DEFS = {
  first_1000: { title: "First $1,000", description: "Earn $1,000 total", target: 1000, field: "totalEarned", reward: 10 },
  first_business: { title: "First Business", description: "Buy your first business", target: 1, field: "businessCount", reward: 15 },
  upgraded: { title: "Upgraded!", description: "Upgrade a business to Level 2", target: 1, field: "businessUpgraded", reward: 10 },
  hustler: { title: "Hustler", description: "Complete 50 hustle taps", target: 50, field: "totalHustleTaps", reward: 20 },
  millionaire: { title: "Millionaire", description: "Reach $1M net worth", target: 1000000, field: "netWorth", reward: 50 },
  employer: { title: "Employer", description: "Hire your first employee", target: 1, field: "placeholder", reward: 20 },
  investor: { title: "Investor", description: "Make your first investment", target: 1, field: "placeholder", reward: 25 },
  level_5: { title: "Level 5", description: "Reach Level 5", target: 5, field: "level", reward: 15 },
  boss_coins_earner: { title: "Boss Coins Earner", description: "Earn 100 Boss Coins total", target: 100, field: "totalBossCoinsEarned", reward: 25 }
}
```

## Seeding

Seed 30 dummy users with:
- Randomized playerName (e.g., "BigMoney Mike", "Cash Queen", "Street Boss", etc.)
- Random avatarEmoji from set: 😎🤑🦊🐺🦁🎩👑💪🔥⚡
- GameState with varied: cash (100-5000000), level (1-25), bossCoins (0-200), totalEarned, reputation (10-95), investmentReturns (0-50000), investmentWinRate (30-90)
- Some with businesses at various levels
- weekStartNetWorth set to slightly less than current net worth for weekly leaderboard variety
