# Bum to Boss Tycoon — Database Schema

## Entity: User

| Field | Type | Constraints |
|-------|------|-------------|
| id | UUID | PK, auto-generated |
| email | String | Unique, required |
| password | String | bcrypt hashed, required |
| name | String | Required |
| playerName | String | Required |
| avatarEmoji | String | Default "😎" |
| createdAt | DateTime | Auto |
| updatedAt | DateTime | Auto-updated |

**Indexes:** unique on email

---

## Entity: GameState

| Field | Type | Constraints |
|-------|------|-------------|
| id | UUID | PK, auto-generated |
| userId | UUID | FK to User.id, unique, required, ON DELETE CASCADE |
| cash | Float | Default 50.0 |
| xp | Integer | Default 0 |
| level | Integer | Default 1 |
| bossCoins | Integer | Default 50 |
| totalEarned | Float | Default 0.0 |
| totalHustleTaps | Integer | Default 0 |
| totalBossCoinsEarned | Integer | Default 50 (tracks lifetime earned for achievement) |
| reputation | Integer | Default 10 (0-100) |
| investmentReturns | Float | Default 0.0 |
| investmentWinRate | Float | Default 0.0 (0-100 percentage) |
| weekStartNetWorth | Float | Default 50.0 |
| weekStartDate | DateTime | Default to current Monday |
| offlineMaxHours | Integer | Default 4 |
| xpBoostUntil | DateTime | Nullable |
| hasAvatarFrame | Boolean | Default false |
| lastActiveAt | DateTime | Default now |
| adCountToday | Integer | Default 0 |
| adCountResetDate | DateTime | Default today |
| createdAt | DateTime | Auto |
| updatedAt | DateTime | Auto-updated |

**Indexes:** unique on userId

**Relationships:** One-to-one with User (userId unique FK)

---

## Entity: Business

| Field | Type | Constraints |
|-------|------|-------------|
| id | UUID | PK, auto-generated |
| userId | UUID | FK to User.id, required, ON DELETE CASCADE |
| businessType | String | Required (e.g., "lemonade_stand") |
| level | Integer | Default 1, min 1, max 3 |
| customName | String | Nullable |
| incomeBoostUntil | DateTime | Nullable |
| purchasedAt | DateTime | Default now |
| createdAt | DateTime | Auto |
| updatedAt | DateTime | Auto-updated |

**Indexes:** index on userId; unique compound on (userId, businessType) — one of each type per user

**Relationships:** Many-to-one with User

---

## Entity: Achievement

| Field | Type | Constraints |
|-------|------|-------------|
| id | UUID | PK, auto-generated |
| userId | UUID | FK to User.id, required, ON DELETE CASCADE |
| achievementKey | String | Required (e.g., "first_1000", "hustler") |
| progress | Integer | Default 0 |
| completed | Boolean | Default false |
| completedAt | DateTime | Nullable |
| createdAt | DateTime | Auto |
| updatedAt | DateTime | Auto-updated |

**Indexes:** unique compound on (userId, achievementKey); index on userId

**Relationships:** Many-to-one with User

---

## Relationships Summary

```
User 1 ──── 1 GameState     (userId unique FK, CASCADE delete)
User 1 ──── * Business       (userId FK, CASCADE delete)
User 1 ──── * Achievement    (userId FK, CASCADE delete)
```

## Seed Data

30 dummy users seeded at application startup (idempotent — skip if users with these emails exist):

- Each with unique email pattern: `bot{n}@bumtoboss.game`
- Password: bcrypt hash of "dummypassword" (these accounts are not loginable in practice)
- playerName from pool: "BigMoney Mike", "Cash Queen", "Street Boss", "Diamond Dave", "Gold Digger", "Hustle King", "Money Maker", "Rich Rita", "Boss Baby", "Coin Master", "Dollar Dan", "Empire Eve", "Fortune Fox", "Grind Guru", "Hustle Hero", "Income Ivy", "Jackpot Joe", "King Cash", "Lucky Lou", "Mega Mitch", "Noble Nick", "Profit Pete", "Queen Bee", "Rise Ryan", "Stack Sam", "Top Tier Tom", "Ultra Uma", "Value Vic", "Wealth Wendy", "Xtreme Xander"
- avatarEmoji randomly from: 😎🤑🦊🐺🦁🎩👑💪🔥⚡
- GameState with randomized values:
  - cash: random 100 – 5,000,000
  - level: random 1 – 25
  - xp: random 0 – (100 × 1.5^(level-1))
  - bossCoins: random 0 – 200
  - totalEarned: cash × random(1.5 – 5.0)
  - totalHustleTaps: random 0 – 500
  - reputation: random 10 – 95
  - investmentReturns: random 0 – 50,000
  - investmentWinRate: random 30 – 90
  - weekStartNetWorth: current net worth × random(0.7 – 0.95)
  - weekStartDate: current week's Monday
  - lastActiveAt: random within last 24 hours
- Businesses: ~60% chance of owning lemonade_stand at random level 1-3
- Achievements: randomly complete 2-5 achievements with appropriate progress values

This ensures leaderboards are populated from first login.
