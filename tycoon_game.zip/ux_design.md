# Bum to Boss Tycoon — UX Specification

## Design Direction

- **Theme**: Dark urban tycoon — deep navy-black backgrounds (#1A1A2E base, #0F0F23 deeper panels), never pure black
- **Primary palette**: Gold (#FFD700) for cash/currency/emphasis, Green (#00C853) for income/positive actions, Violet (#7C3AED) for Boss Coins/premium
- **Accent colors**: Red (#EF4444) for locked/cooldown states, Cyan (#06B6D4) for XP bars
- **Color application**: Gradient buttons [Gold → #FFA000], glass-effect cards with subtle gold border glow, frosted nav bar
- **Typography**: "Bangers" for display/headings (bold tycoon feel), "Nunito" for body text via Google Fonts. Scale: Display 32px → Heading 22px → Body 16px → Caption 13px
- **Backgrounds**: Layered gradient from #0F0F23 → #1A1A2E → #252547, subtle diagonal stripe pattern overlay at 3% opacity
- **Spacing**: 8pt grid throughout. Border radius: cards 16px, buttons 12px, avatars 50% round
- **Emoji icons**: Used extensively as visual identifiers for hustles, businesses, achievements
- **Cash formatting**: Always K/M/B suffix (e.g., $1.2K, $3.5M)

## Animation & Motion

- **Screen transitions**: Smooth fade+slide matching navigation direction
- **Tap feedback**: Scale 0.95 spring + haptic on hustle taps; cash amount floats up and fades (+$5 pop-up)
- **Cooldown timers**: Circular progress ring animating countdown
- **Level-up**: Confetti burst modal with scale-in animation
- **Income ticks**: Subtle pulse on cash display when passive income arrives
- **Cards**: Staggered fade-in on list entry, press scale 0.97
- **Progress bars**: Smooth animated fill transitions (XP bar, achievement progress)
- **Loading**: Skeleton shimmer on leaderboard rows and game state load
- **Pull-to-refresh**: On leaderboard screens
- **Respect reduced motion**: Disable animations when system preference set
- **Haptics**: On hustle taps, level-up, achievement unlock, purchase confirmation; skip on web

## Screens

### Auth Screens (Unauthenticated Stack)

#### Login Screen (`app/auth/login.tsx`)
- **Purpose**: Authenticate returning players
- **Layout**: Centered card on gradient background
  - App logo/title "Bum to Boss Tycoon" in Bangers font, gold color, with 💰 emoji
  - Tagline: "Build Your Empire" in muted gold
  - Email input (floating label, keyboard type email)
  - Password input (floating label, secure entry, eye toggle)
  - "Login" gradient button [Gold → #FFA000], full width
  - "Don't have an account? Sign Up" text link below → pushes to Signup screen
- **Actions**: Submit calls login; on success AuthProvider state updates and layout switches to authenticated tabs
- **States**: Loading (button shows spinner), error (shake inputs, red error message below form)

#### Signup Screen (`app/auth/signup.tsx`)
- **Purpose**: Register new players
- **Layout**: Centered card on gradient background
  - App title smaller at top
  - Player Name input (floating label, required)
  - Email input (floating label, keyboard type email)
  - Password input (floating label, secure entry, min 6 chars)
  - "Start Your Empire" gradient button [Gold → #FFA000], full width
  - "Already have an account? Login" text link → pops back to Login
- **Actions**: Submit calls signup; on success AuthProvider state updates and layout switches to authenticated tabs
- **States**: Loading, validation errors per field, server error display

### Authenticated Screens — Tabs

#### Home Tab (`app/tabs/home.tsx`) — 🏠 Home
- **Purpose**: Dashboard overview of player status and quick stats
- **Layout** (scrollable):
  - **Player Header Card** (glass effect, gold border glow):
    - Avatar emoji (large, 48px) with optional premium frame indicator
    - Player name (Bangers font, white)
    - Level badge: "Lv. {level}" in gold pill
    - XP progress bar (Cyan fill on dark track, shows "{currentXP}/{requiredXP} XP")
    - Boss Coins display: 💎 {count} in violet text, top-right of card
  - **Cash Display** (prominent, centered):
    - "$" prefix in gold, amount in large Bangers font (36px), white
    - Subtitle: "💰 +${passiveIncomeRate}/sec" in green if businesses owned, otherwise "Tap hustles to earn!"
  - **Quick Stats Row** (3 mini cards in horizontal row):
    - Total Earned: 💵 ${totalEarned}
    - Businesses: 🏪 {count}
    - Hustle Taps: 👆 {totalHustleTaps}
  - **Recent Achievements Section**:
    - Header: "🏆 Achievements" with count badge
    - Horizontal scroll of up to 3 most recent unlocked achievement chips (emoji + title)
    - "View All →" link → navigates to Profile tab
  - **Passive Income Summary** (if businesses owned):
    - Card showing each owned business name, emoji, and income rate
- **Data needed**: Player profile, game state (cash, xp, level, bossCoins, totalEarned, totalHustleTaps), owned businesses with income rates, recent achievements

#### Hustle Tab (`app/tabs/hustle.tsx`) — 💼 Hustle
- **Purpose**: Tap-based jobs to earn cash
- **Layout** (scrollable):
  - Header: "💼 Hustles" in Bangers font
  - Subtitle: "Tap to earn cash and XP!"
  - **3 Hustle Cards** (stacked vertically, glass effect):
    - Each card shows:
      - Left: Large emoji icon (🚗 Wash Cars, 🍔 Deliver Food, 🍋 Sell Lemonade)
      - Center: Name (Bangers), reward ("$5 + 2 XP" in gold/cyan), cooldown ("3s cooldown" caption)
      - Right: Large tap button (gradient gold, circular)
    - **Unlocked state**: Tap button active, gold glow
    - **Cooldown state**: Button disabled (gray), circular countdown timer overlay showing seconds remaining, pulsing ring
    - **Locked state**: Entire card dimmed with overlay, lock icon 🔒, "Unlocks at Level {n}" text
  - On tap:
    - Button scales down with spring + haptic
    - Cash pop-up floats up from button ("+$5" in gold, fades out over 1s)
    - XP pop-up smaller ("+2 XP" in cyan)
    - Cash display at top updates
    - Cooldown timer starts
- **Data needed**: Player level (for unlock checks), cooldown state (local timers), cash/xp from hustle endpoint response

#### Business Tab (`app/tabs/business.tsx`) — 🏪 Business
- **Purpose**: Buy and upgrade businesses for passive income
- **Layout** (scrollable):
  - Header: "🏪 Your Empire" in Bangers font
  - Cash display bar at top: "💰 ${cash}" for quick reference
  - **Business Cards** (one per business type):
    - **Owned business card** (gold border, glass effect):
      - Emoji icon (🍋), business name (editable if renamed), "Lv. {level}" badge
      - Income rate: "💰 ${rate}/sec" in green
      - If income boost active: "🔥 2x Boost" badge with countdown timer
      - Upgrade button: "⬆️ Upgrade to Lv.{next} — ${cost}" gradient button
        - Disabled (gray) if insufficient cash, shows cost in red
        - Max level (3): button replaced with "MAX LEVEL ✨" gold text
      - "📺 Watch Ad for 2x Boost" button (green outline) if no active boost
    - **Locked business card** (dimmed, dashed border):
      - Emoji icon, name, "🔒 Costs ${price}"
      - "Buy" button: gradient gold if enough cash, gray if not
      - Income preview: "Will earn ${rate}/sec"
- **Data needed**: All business definitions, owned businesses with levels/boosts, player cash

#### Leaderboard Tab (`app/tabs/leaderboard.tsx`) — 🏆 Leaderboard
- **Purpose**: View 5 leaderboard types
- **Layout**:
  - Header: "🏆 Leaderboards" in Bangers font
  - **5 horizontal scrollable chips** at top (pill-shaped toggle buttons):
    - 💰 Net Worth | 🏢 Empire | 📈 Investment | ⭐ Reputation | 🗓️ Weekly Boss
    - Selected chip: gold fill; unselected: dark outline
  - **Leaderboard List** (FlashList):
    - Pull-to-refresh
    - Each row:
      - Rank number (1-3 get 👑 crown icon, gold/silver/bronze tint)
      - Avatar emoji
      - Player name
      - Primary stat (formatted with K/M/B)
      - Secondary stat (level badge, count, percentage, or timer depending on type)
    - **Current player row**: Highlighted with gold border/glow, pinned at bottom if not in visible top list
    - Skeleton shimmer while loading
  - **Weekly Boss** specific: Countdown timer to next Monday at top of list ("Resets in 2d 14h 32m")
- **Data needed per type**:
  - Net Worth: rank, name, avatarEmoji, netWorth, level
  - Empire: rank, name, avatarEmoji, empireValue, businessCount
  - Investment: rank, name, avatarEmoji, investmentReturns, winRate
  - Reputation: rank, name, avatarEmoji, reputation, title
  - Weekly: rank, name, avatarEmoji, weeklyGrowth, (countdown is client-calculated to next Monday)

#### Profile Tab (`app/tabs/profile.tsx`) — 👤 Profile
- **Purpose**: Player stats, achievements, Boss Coins store, settings
- **Layout** (scrollable):
  - **Profile Header Card** (glass, gold glow):
    - Large avatar emoji (64px) with frame if purchased
    - Player name, Level badge, "Member since {date}"
    - Boss Coins: 💎 {count} in violet, prominent
  - **Stats Grid** (2x3 grid of mini stat cards):
    - Total Earned, Net Worth, Hustle Taps, Businesses Owned, Reputation, Level
  - **Achievements Section**:
    - Header: "🏆 Achievements ({unlocked}/{total})"
    - List of achievement cards:
      - Emoji icon, title, description
      - Progress bar (green fill) with "{current}/{target}" text
      - Completed: green checkmark, "Reward: {x} 💎 Claimed" 
      - Locked: gray, progress shown
  - **Boss Coins Store Section**:
    - Header: "💎 Boss Coins Store"
    - Note banner: "Boss Coins are for customization and convenience — not leaderboard advantages" (muted text, info icon)
    - Store item cards (vertical list):
      - Each: emoji, name, description, cost in 💎
      - "Buy" button (violet gradient) if enough coins, disabled if not
      - Items:
        - ⏭️ Skip Hustle Cooldown — 5 💎
        - ✏️ Business Name Change — 10 💎
        - 🌙 Offline Income Boost (6hr) — 25 💎
        - ⚡ XP Booster 1hr (2x XP) — 20 💎
        - 💵 Cash Bundle $500 — 30 💎
        - 💰 Cash Bundle $2,000 — 100 💎
        - 🖼️ Premium Avatar Frame — 50 💎
  - **Logout Button**: Red outline button at bottom, "Log Out"
- **Data needed**: Full player profile, game state, all achievements with progress, boss coins balance

### Non-Tab Screens

#### Welcome Back Modal (shown on Home after login if offline income > 0)
- **Purpose**: Show offline earnings and offer ad doubler
- **Presented as**: Modal overlay on Home screen (not a separate route — triggered by game state load)
- **Layout**:
  - Dark backdrop blur
  - Card (glass effect, gold border):
    - "Welcome Back! 🎉" heading
    - "You earned ${offlineIncome} while away!" in gold, large
    - "Time away: {hours}h {minutes}m"
    - "Collect" gradient gold button
    - "📺 Watch Ad to Double It!" green button (if ads remaining today)
    - Ad count: "{remaining}/5 ads left today" caption
- **Actions**: Collect dismisses and adds income; Watch Ad opens simulated ad modal, then doubles and collects

#### Simulated Ad Modal (overlay, not a route)
- **Purpose**: Fake rewarded ad experience
- **Layout**:
  - Full-screen dark overlay
  - Centered card with animated gradient background (shifting gold/violet/green)
  - "Ad" text placeholder
  - Progress bar filling over 15 seconds
  - Countdown: "Skip in {5-0}s" then "Skip ✕" button appears
  - After completion or skip: reward granted, modal dismisses

#### Level-Up Modal (overlay, not a route)
- **Purpose**: Celebrate level advancement
- **Layout**:
  - Confetti animation background
  - "🎉 Level Up!" large Bangers text in gold
  - "Level {n}" with glow effect
  - If milestone (every 5 levels): "+20 💎 Boss Coins!" in violet
  - New unlocks listed (if any): "🔓 Unlocked: Deliver Food hustle!"
  - "Continue" button

## Navigation

### File Structure
```
app/
  _layout.tsx          — Root layout: AuthProvider wrapper, checks auth state
  auth/
    _layout.tsx        — Unauthenticated stack layout; if isLoading show splash, if isAuthenticated <Redirect href="/tabs/home" />
    login.tsx          — Login screen
    signup.tsx         — Signup screen
  tabs/
    _layout.tsx        — Protected tab layout; if isLoading show splash, if !isAuthenticated <Redirect href="/auth/login" />; renders <Tabs> with 5 tabs
    home.tsx           — 🏠 Home tab
    hustle.tsx         — 💼 Hustle tab
    business.tsx       — 🏪 Business tab
    leaderboard.tsx    — 🏆 Leaderboard tab
    profile.tsx        — 👤 Profile tab
```

### Navigation Flow
- **Unauthenticated**: Stack with Login (initial) and Signup screens
- **Authenticated**: Bottom tab bar with 5 tabs (Home, Hustle, Business, Leaderboard, Profile)
- **Tab bar style**: Frosted glass dark background, gold active icon/label, muted inactive
- **Auth transitions**: State-driven via layout guards — AuthProvider state updates cause layout `<Redirect>` to fire, no imperative navigation from auth screens
- **Modals** (Welcome Back, Simulated Ad, Level-Up): Rendered as overlay components within the authenticated layout, controlled by game state context, not as separate routes

### Game State Context
- `GameProvider` wraps authenticated screens, provides:
  - `gameState` (cash, xp, level, bossCoins, businesses, achievements, etc.)
  - `isLoading` (true while fetching initial state)
  - `doHustle(hustleType)` — calls backend, updates local state
  - `buyBusiness(businessType)` — calls backend, updates local state
  - `upgradeBusiness(businessId)` — calls backend, updates local state
  - `spendBossCoins(itemKey)` — calls backend, updates local state
  - `syncState()` — saves to backend
  - `offlineIncome` — calculated on initial load, triggers Welcome Back modal
- Auto-sync every 30 seconds via interval
- AsyncStorage fallback: save state locally on every update, load from local if network fails

### Component Standards
- **Buttons**: Gradient fill (gold for primary, green for income, violet for premium), press scale 0.97 + haptic, loading spinner state, disabled gray state
- **Cards**: Rounded 16px, glass effect with subtle colored border glow (gold for owned, gray for locked), press animation on interactive cards
- **Inputs**: Floating labels, focus animation (border color shift to gold), error shake + red border, validation messages below
- **Lists**: @shopify/flash-list for leaderboard, staggered fade-in entry
- **Progress bars**: Rounded, animated fill, colored by context (cyan for XP, green for achievements, gold for cooldowns)
- **States**: Skeleton shimmer loading, empty states with emoji + messaging, error states with retry button
- **Accessibility**: Contrast ≥ 4.5:1 (gold on dark passes), touch targets 44pt+, accessible labels on all interactive elements
